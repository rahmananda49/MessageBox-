package com.rahmananda.messegebox;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    // Deklarasi
    private Button btnToast, btnAlertDialog, btnSnackbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialisasi
        btnToast = findViewById(R.id.btn_toast);
        btnAlertDialog = findViewById(R.id.btn_alert_dialog);
        btnSnackbar = findViewById(R.id.btn_snackbar);

        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Ini adalah Tampilan Toast", Toast.LENGTH_SHORT).show();
            }
        });

        btnAlertDialog.setOnClickListener(this);
        btnSnackbar.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        switch (id){
            case R.id.btn_alert_dialog:
                AlertDialog.Builder tampil = new AlertDialog.Builder(this);
                tampil.setTitle("Konfirmasi");
                tampil.setMessage("Apakah anda yakin dengan dia?");
                tampil.setIcon(R.drawable.ic_launcher_background);
                tampil.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "Ini adalah aksi pilihan 'ya' ", Toast.LENGTH_SHORT).show();

                    }
                })
                        .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "Ini adalah aksi pilihan 'tidak' ", Toast.LENGTH_SHORT).show();
                            }
                        });
                    tampil.show();
                    break;

            case R.id.btn_snackbar:

                Snackbar tampil2 = Snackbar.make(findViewById(R.id.linear), "ini Adalah Tampilan Snackbar", Snackbar.LENGTH_LONG);
                tampil2.setAction("pilih", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this, "Ini adalah pilihan anda", Toast.LENGTH_SHORT).show();
                    }
                });
                tampil2.show();
                break;
        }
    }
}
